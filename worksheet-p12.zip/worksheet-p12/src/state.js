// P12 — Satu objek state reaktif dan fungsi pengubahnya (Farrel Priya Arka Agrapana, 25523185)
// Tidak ada render(): template yang menggambar ulang saat state berubah.
import { reactive } from 'vue'
import { daftarProyek } from './data.js'

export const KATEGORI_BAWAAN = 'semua'

export const state = reactive({
  daftarProyek: daftarProyek,
  kategoriAktif: KATEGORI_BAWAAN,
  notisia: [],
  statusNotisia: 'memuat', // memuat | berhasil | kosong | gagal
  pesanGalat: '',
})

export function pilihKategori(nilai) {
  state.kategoriAktif = nilai // tanpa render()
}

export function mulaiNotisia() {
  state.statusNotisia = 'memuat'
  state.pesanGalat = ''
}

export function isiNotisia(daftar) {
  state.notisia = daftar
  state.statusNotisia = daftar.length === 0 ? 'kosong' : 'berhasil'
}

export function gagalNotisia(pesan) {
  state.notisia = []
  state.statusNotisia = 'gagal'
  state.pesanGalat = pesan
}
