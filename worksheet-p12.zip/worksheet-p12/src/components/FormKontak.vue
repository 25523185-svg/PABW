<script setup>
import { reactive, ref } from 'vue'

// Isi form hanya hidup di komponen ini (ref/reactive lokal) dan tidak pernah disimpan.
const aturan = {
  nama: (nilai) =>
    nilai.length >= 3 ? '' : 'Nama belum diisi. Ketik nama lengkap Anda, minimal 3 huruf.',
  email: (nilai) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nilai) ? '' : 'Email belum benar. Tulis seperti nama@contoh.com.',
  nim: (nilai) =>
    /^[0-9]{8}$/.test(nilai) ? '' : 'NIM harus delapan digit angka, contoh 25523185.',
  pesan: (nilai) =>
    nilai.length >= 10 ? '' : 'Pesan terlalu singkat. Tulis minimal 10 karakter.',
}
const nama = Object.keys(aturan)

const isi = reactive({ nama: '', email: '', nim: '', pesan: '' })
const galat = reactive({ nama: '', email: '', nim: '', pesan: '' })
const status = ref('')
const tombolDitahan = ref(false)
const form = ref(null)

function periksa(kolom) {
  galat[kolom] = aturan[kolom](isi[kolom].trim())
  return galat[kolom] === ''
}

function semuaSah() {
  return nama.every((kolom) => aturan[kolom](isi[kolom].trim()) === '')
}

function ketik(kolom) {
  status.value = ''
  periksa(kolom)
  tombolDitahan.value = !semuaSah()
}

function kirim() {
  const hasil = nama.map(periksa)
  const pertamaSalah = nama.find((_, i) => !hasil[i])
  if (pertamaSalah) {
    tombolDitahan.value = true
    form.value.elements[pertamaSalah].focus() // arahkan ke kolom yang perlu diperbaiki
    return
  }
  status.value = 'Terima kasih, pesan Anda sudah tercatat.'
  nama.forEach((kolom) => {
    isi[kolom] = ''
    galat[kolom] = ''
  })
  tombolDitahan.value = false
}
</script>

<template>
  <form ref="form" action="#" method="post" novalidate @submit.prevent="kirim">
    <fieldset>
      <legend>Data pengirim</legend>

      <p class="form-kolom">
        <label for="nama">Nama lengkap</label>
        <input id="nama" name="nama" type="text" autocomplete="name" required
               v-model="isi.nama" @input="ketik('nama')"
               :aria-invalid="galat.nama ? 'true' : null" aria-describedby="nama-galat">
        <span id="nama-galat" class="galat" :hidden="galat.nama === ''">{{ galat.nama }}</span>
      </p>

      <p class="form-kolom">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" autocomplete="email" required
               v-model="isi.email" @input="ketik('email')"
               :aria-invalid="galat.email ? 'true' : null" aria-describedby="email-galat">
        <span id="email-galat" class="galat" :hidden="galat.email === ''">{{ galat.email }}</span>
      </p>

      <p class="form-kolom">
        <label for="nim">NIM</label>
        <input id="nim" name="nim" type="text" inputmode="numeric" pattern="[0-9]{8}" required
               v-model="isi.nim" @input="ketik('nim')"
               :aria-invalid="galat.nim ? 'true' : null" aria-describedby="nim-bantuan nim-galat">
        <span id="nim-bantuan">Delapan digit angka, contoh 25523185.</span>
        <span id="nim-galat" class="galat" :hidden="galat.nim === ''">{{ galat.nim }}</span>
      </p>

      <p class="form-kolom">
        <label for="pesan">Pesan</label>
        <textarea id="pesan" name="pesan" rows="4" required
                  v-model="isi.pesan" @input="ketik('pesan')"
                  :aria-invalid="galat.pesan ? 'true' : null" aria-describedby="pesan-galat"></textarea>
        <span id="pesan-galat" class="galat" :hidden="galat.pesan === ''">{{ galat.pesan }}</span>
      </p>

      <button type="submit" :disabled="tombolDitahan">Kirim</button>
      <p id="status-form" role="status">{{ status }}</p>
    </fieldset>
  </form>
</template>
