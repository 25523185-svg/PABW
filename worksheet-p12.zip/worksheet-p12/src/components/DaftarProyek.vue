<script setup>
import { computed } from 'vue'
import { state } from '../state.js'

const tampil = computed(() =>
  state.daftarProyek.filter(
    (proyek) => state.kategoriAktif === 'semua' || proyek.kategori === state.kategoriAktif
  )
)
</script>

<template>
  <ul id="daftar">
    <li v-for="proyek in tampil" :key="proyek.id" class="kartu">
      <h3>{{ proyek.judul }}</h3>
      <p>Praktikum {{ proyek.praktikum }} · {{ proyek.tahun }} · {{ proyek.selesai ? 'selesai' : 'sedang dikerjakan' }}</p>
      <p>{{ proyek.deskripsi }}</p>
    </li>
  </ul>
  <p id="pesan-kosong" v-if="tampil.length === 0">Tidak ada proyek pada kategori itu.</p>
</template>
