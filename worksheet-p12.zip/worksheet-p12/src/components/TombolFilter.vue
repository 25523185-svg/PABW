<script setup>
import { state, pilihKategori } from '../state.js'

const kategori = [
  { nilai: 'semua', label: 'Semua' },
  { nilai: 'web', label: 'Web' },
  { nilai: 'data', label: 'Data' },
]
</script>

<template>
  <div id="filter">
    <button
      v-for="k in kategori"
      :key="k.nilai"
      type="button"
      :class="{ aktif: state.kategoriAktif === k.nilai }"
      @click="pilihKategori(k.nilai)"
    >{{ k.label }}</button>
  </div>
</template>
