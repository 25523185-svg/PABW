// P12 — localStorage dari P11, dipindahkan apa adanya (Farrel Priya Arka Agrapana, 25523185)
// Hanya berkas ini yang membaca/menulis localStorage. Yang disimpan: pilihan tampilan saja.
export const KUNCI = "pabw-p11";
export const VERSI = 2;

export function simpan(keadaan) {
  const isi = { versi: VERSI, kategoriAktif: keadaan.kategoriAktif };
  try {
    localStorage.setItem(KUNCI, JSON.stringify(isi));
  } catch (galat) {
    console.warn("Pilihan tidak tersimpan:", galat.message); // halaman tetap jalan
  }
}

export function muat() {
  try {
    const isi = JSON.parse(localStorage.getItem(KUNCI));
    if (isi?.versi !== VERSI) {
      localStorage.removeItem(KUNCI); // bentuk lama atau belum ada: buang
      return null;
    }
    return isi;
  } catch {
    try { localStorage.removeItem(KUNCI); } catch { /* penyimpanan terkunci */ }
    return null; // isi rusak: pakai nilai bawaan
  }
}

export function aturUlang() {
  try { localStorage.removeItem(KUNCI); } catch { /* penyimpanan terkunci */ }
}
