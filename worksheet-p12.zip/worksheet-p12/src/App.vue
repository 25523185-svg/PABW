<script setup>
import { onMounted, watch } from 'vue'
import KepalaProfil from './components/KepalaProfil.vue'
import TombolFilter from './components/TombolFilter.vue'
import DaftarProyek from './components/DaftarProyek.vue'
import FormKontak from './components/FormKontak.vue'
import { profil, tahunIni } from './data.js'
import { state, KATEGORI_BAWAAN, mulaiNotisia, isiNotisia, gagalNotisia } from './state.js'
import { muat, simpan, aturUlang } from './simpanan.js'
import { ambilNotisia } from './api.js'

onMounted(async () => {
  document.title = `Profil ${profil.nama} — PABW 2026/2027`

  // Simpanan dibaca satu kali; VERSI diperiksa di dalam muat(), bentuk lama dibuang.
  const isi = muat()
  const sah = ['semua', ...new Set(state.daftarProyek.map((p) => p.kategori))]
  if (isi && sah.includes(isi.kategoriAktif)) state.kategoriAktif = isi.kategoriAktif

  // Lapisan data dari P10 dipakai apa adanya
  mulaiNotisia()
  try {
    isiNotisia(await ambilNotisia())
  } catch (galat) {
    gagalNotisia(galat.message)
  }
})

// Setiap perubahan state ditulis ke simpanan.
watch(state, (nilai) => simpan(nilai), { deep: true })

function aturUlangPilihan() {
  aturUlang()
  state.kategoriAktif = KATEGORI_BAWAAN
  simpan(state) // ditulis ulang dengan nilai bawaan, bukan dibiarkan kosong
}
</script>

<template>
  <a class="lewati" href="#utama">Lewati ke konten utama</a>

  <KepalaProfil :profil="profil" />

  <main id="utama">

    <section id="tentang">
      <h2>Tentang saya</h2>

      <figure class="foto">
        <img src="/media/foto-profil.jpg"
             alt="Foto diri Farrel Priya Arka Agrapana."
             width="480" height="655" loading="lazy">
        <figcaption>Foto profil saya.</figcaption>
      </figure>

      <p>Saya mahasiswa Program Studi Informatika Universitas Islam Indonesia,
         kelas E. Saya tertarik pada pengembangan web, khususnya bagian
         tampilan, karena di sana keputusan teknis langsung terlihat
         hasilnya. Semester ini saya sedang memperdalam CSS, khususnya
         design token dan tata letak dengan flexbox.</p>

      <div class="table-wrap">
      <table>
        <caption>Kegiatan yang saya ikuti semester ini</caption>
        <thead>
          <tr>
            <th scope="col">Kegiatan</th>
            <th scope="col">Peran</th>
            <th scope="col">Waktu</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">Praktikum PABW</th>
            <td>Peserta</td>
            <td><time datetime="2026-09">September 2026</time></td>
          </tr>
          <tr>
            <th scope="row">Kelas Terbuka Kampus</th>
            <td>Peserta</td>
            <td><time datetime="2026-10">Oktober 2026</time></td>
          </tr>
          <tr>
            <th scope="row">Organisasi kemahasiswaan</th>
            <td>Anggota</td>
            <td><time datetime="2026">2026</time></td>
          </tr>
        </tbody>
      </table>
      </div>
    </section>

    <section id="karya">
      <h2>Proyek</h2>

      <TombolFilter />

      <button type="button" id="atur-ulang" @click="aturUlangPilihan">Atur ulang pilihan</button>
      <DaftarProyek />

      <div id="notisia">
        <h3>Notisia Kampus</h3>
        <p id="status-notisia" role="status">
          <template v-if="state.statusNotisia === 'memuat'">Memuat notisia...</template>
          <template v-else-if="state.statusNotisia === 'gagal'">Gagal memuat data: {{ state.pesanGalat }}</template>
          <template v-else-if="state.statusNotisia === 'kosong'">Belum ada notisia</template>
        </p>
        <ul id="daftar-notisia">
          <li v-for="n in state.notisia" :key="n.id" class="kartu">
            <h4>{{ n.judul }}</h4>
            <p>{{ n.kategori }} · {{ n.tanggal }}{{ n.penting ? ' · penting' : '' }}</p>
            <p>{{ n.ringkasan }}</p>
          </li>
        </ul>
      </div>
    </section>

    <section id="kontak">
      <h2>Hubungi saya</h2>
      <p>Isi formulir berikut. Semua kolom bertanda wajib harus diisi.</p>
      <FormKontak />
    </section>

    <section id="lini-masa">
      <h2>Perjalanan saya</h2>
      <ol class="lini">
        <li><time datetime="2025-08">Agustus 2025</time> — mulai kuliah di Informatika UII.</li>
        <li><time datetime="2026-09">September 2026</time> — pertama kali menulis HTML dan CSS di praktikum PABW.</li>
        <li><time datetime="2026-09">September 2026</time> — membangun halaman profil ini dengan design token.</li>
      </ol>
    </section>

    <section id="keterampilan">
      <h2>Keterampilan</h2>
      <dl class="keterampilan">
        <template v-for="k in profil.keahlian" :key="k.nama">
          <dt>{{ k.nama }}</dt>
          <dd>{{ k.deskripsi }}</dd>
        </template>
      </dl>
    </section>

    <section id="tanya-jawab">
      <h2>Tanya jawab</h2>

      <details>
        <summary>Apa yang sedang saya pelajari?</summary>
        <p>CSS dan cara menyusun tampilan yang konsisten lewat design token.</p>
      </details>

      <details>
        <summary>Alat apa yang saya pakai sehari-hari?</summary>
        <p>VS Code dan Chrome. DevTools saya buka setiap kali mengerjakan tampilan.</p>
      </details>

      <details>
        <summary>Mengapa saya memilih warna biru navy untuk halaman ini?</summary>
        <p>Warna itu saya ambil dari kesan tegas dan teknis yang ingin saya tampilkan di portofolio saya.</p>
      </details>
    </section>

  </main>

  <footer class="kaki">
    <p>{{ profil.nama }} · {{ profil.nim }} · <time :datetime="String(tahunIni)">{{ tahunIni }}</time></p>
  </footer>
</template>
